require("./system/module.js")

// >~~~~~~ Setting Bot & Owner  ~~~~~~~< //
global.owner = "6283875040924"
global.namabot = "—͟͞𝖃𝖊𝖓𝖔𝖝𝖉𝕺𝖋𝖋𝖎𝖈𝖎𝖆𝖑" 
global.namaowner = "—͟͞𝙓𝙀𝙉𝙊𝙓𝘿𝙊𝙁𝙁𝙄𝘾𝙄𝘼𝙇"
global.linkgc = ''
global.linksaluran = "https://whatsapp.com/channel/0029VbBT8ec6xCSNfq9uNT0P"
global.fotomenu = "https://t1.pixhost.to/thumbs/7858/630687065_img-20250809-wa0125.jpg"
global.packname = "—͟͟͞𝐗𝐞𝐧𝐨𝐱𝐝𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥"
global.author = "—͟͞𝐗𝐞𝐧𝐨𝐱𝐝𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥"


// >~~~~~~~~ Setting Channel ~~~~~~~~~< //
global.idsaluran = "120363404310101061@newsletter"
global.namasaluran = "—͟͞𝐗𝐞𝐧𝐨𝐱𝐝𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥"


global.image = "https://t1.pixhost.to/thumbs/7858/630687065_img-20250809-wa0125.jpg"

// >~~~~~~~~ Setting Payment ~~~~~~~~~< //
global.dana = "083879430587"
global.ovo = "Belum tersedia"
global.gopay = "Belum tersedia"
global.qris = "https://files.catbox.moe/wvwvit.jpg"


// >~~~~~~~~ Setting Api Panel ~~~~~~~~< //
global.egg = "15" // Isi id egg
global.nestid = "5" // Isi id nest
global.loc = "1" // Isi id location
global.domain = "" // isi domain 
global.apikey = "" // Isi api ptla
global.capikey = "" // Isi api ptlc


// >~~~~~~~~ Setting Message ~~~~~~~~~< //
global.msg = {
wait: "Memproses . . .", 
owner: "Fitur ini khusus untuk owner!", 
group: "Fitur ini untuk dalam grup!", 
admin: "Fitur ini untuk admin grup!", 
botadmin: "Fitur ini hanya untuk bot menjadi admin"
}


// >~~~~~~~ Setting Api Domain ~~~~~~~~< //
global.subdomain = {
"serverku.biz.id": {
"zone": "4e4feaba70b41ed78295d2dcc090dd3a", 
"apitoken": "oof_QRNdUC4aMQ3xIB8dmkGaZu7rk2J-0P_tN55l"
}, 
"privatserver.my.id": {
"zone": "699bb9eb65046a886399c91daacb1968", 
"apitoken": "CrQMyDn2fhchlGne2ogAw7PvJLsg4x8vasBv__6D"
}, 
"panelwebsite.biz.id": {
"zone": "2d6aab40136299392d66eed44a7b1122", 
"apitoken": "uByz8U9jRoor5FiZekdcNhzlWBpr9mekqVaXgR1w"
}, 
"mypanelstore.web.id": {
"zone": "c61c442d70392500611499c5af816532", 
"apitoken": "N_VhWv2ZK6UJxLdCnxMfZx9PtzAdmPGM3HmOjZR4"
}, 
"pteroserver.us.kg": {
"zone": "f693559a94aebc553a68c27a3ffe3b55", 
"apitoken": "qRxwgS3Kl_ziCXti2p4BHbWTvGUYzAuYmVM28ZEp"
}, 
"digitalserver.us.kg": {
"zone": "df13e6e4faa4de9edaeb8e1f05cf1a36", 
"apitoken": "sH60tbg10UH8gpNrlYpf3UMse1CNJ01EKJ69YVqb"
}, 
"shopserver.us.kg": {
"zone": "54ca38e266bfdf2dcdb7f51fd79c2db5", 
"apitoken": "GRe4rg-vhb4c8iSjKCALHJC0LaxkzNPgmmgcDGpm"
}
}


let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.cyan("File Update => "), chalk.cyan.bgBlue.bold(`${__filename}`))
delete require.cache[file]
require(file)
})